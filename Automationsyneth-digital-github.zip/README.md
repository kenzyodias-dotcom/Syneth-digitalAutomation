# Syneth Digital Website

**synethdigital.org** — Full-service digital marketing agency, Lagos Nigeria.

---

## Quarterly Blog Auto-Updater

Every 3 months, a GitHub Action automatically:
1. Searches for a recent Lagos marketing event
2. Writes a professional blog article using Claude AI
3. Opens a Pull Request for your review
4. You approve → it goes live on synethdigital.org

---

## One-Time Setup (10 minutes)

### Step 1: Add your Claude API key to GitHub Secrets

1. Go to your GitHub repository
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Name: `CLAUDE_API_KEY`
5. Value: your Claude API key (sk-ant-api03-...)
6. Click **Add secret**

### Step 2: Connect this repo to Vercel

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **Add New Project**
3. Import your GitHub repository `kenzyodias-dotcom/syneth-digital`
4. Vercel will detect it automatically — click **Deploy**
5. Go to your Vercel project settings → **Domains** → add `synethdigital.org`

From now on, every time you merge a Pull Request, Vercel automatically redeploys your site. No more manual uploads.

### Step 3: Test the automation

1. Go to your repository → **Actions** tab
2. Click **Quarterly Blog Updater**
3. Click **Run workflow** → **Run workflow**
4. Wait 2 minutes
5. A new Pull Request will appear — review and merge it

---

## How the Pull Request system works

- Every 3 months a PR opens automatically
- You get a GitHub notification by email
- Open the PR, check the article looks good
- Click **Merge pull request**
- Vercel deploys in about 60 seconds
- Article is live on synethdigital.org

You are always in control. Nothing goes live without your approval.

---

## File Structure

```
index.html                          ← Your website
scripts/update_blog.py              ← AI blog updater script
.github/workflows/quarterly-blog-update.yml  ← Automation schedule
README.md                           ← This file
```
