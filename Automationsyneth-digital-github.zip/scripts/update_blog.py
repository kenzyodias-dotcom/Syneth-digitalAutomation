"""
Syneth Digital — Quarterly Blog Updater
Finds a recent Lagos marketing event and adds it to the blog.
"""

import os
import re
import json
import anthropic
from datetime import datetime

# ── CONFIG ────────────────────────────────────────────────────
HTML_FILE    = "index.html"
CLAUDE_MODEL = "claude-sonnet-4-6"
API_KEY      = os.environ.get("CLAUDE_API_KEY")

# Unsplash photos for event articles (rotates each quarter)
EVENT_PHOTOS = [
    "https://images.unsplash.com/photo-1559223607-a43c990c692c?auto=format&fit=crop&w=900&h=500&q=80",
    "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=900&h=500&q=80",
    "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=900&h=500&q=80",
    "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=900&h=500&q=80",
]

def get_photo():
    """Pick a photo based on the current quarter."""
    quarter = (datetime.now().month - 1) // 3
    return EVENT_PHOTOS[quarter % len(EVENT_PHOTOS)]

def find_event_and_write_article(client):
    """Ask Claude to find a recent Lagos marketing event and write an article."""

    current_date = datetime.now().strftime("%B %Y")

    prompt = f"""Today is {current_date}. 

Your task:
1. Search the web for ONE real, recent marketing or digital marketing event that happened in Lagos, Nigeria in the last 3 months.
2. Write a professional blog article about it for Syneth Digital, a Lagos-based digital marketing agency.

The article MUST be returned as a valid JSON object with exactly these fields:
{{
  "date": "Mon DD YYYY",
  "title": "Article title here",
  "excerpt": "One sentence summary under 150 characters",
  "body": "Full article body. Use \\\\n\\\\n to separate paragraphs. No quotes inside the text."
}}

Rules for the body:
- 3 to 5 paragraphs
- Cover: what the event was, key highlights or findings, why it matters for Nigerian marketers
- Professional tone, factual, no made-up statistics
- No apostrophes or single quotes anywhere in the body text (use full words instead eg use cannot instead of can't)
- No double quotes inside the body (use alternative phrasing)
- Keep each paragraph under 100 words

Return ONLY the JSON object, nothing else."""

    response = client.messages.create(
        model=CLAUDE_MODEL,
        max_tokens=1500,
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
        messages=[{"role": "user", "content": prompt}]
    )

    # Extract the text response
    text_response = ""
    for block in response.content:
        if block.type == "text":
            text_response += block.text

    # If Claude used web search, get the final text
    if not text_response and response.stop_reason == "tool_use":
        # Continue the conversation to get the final answer
        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": response.content}
        ]
        # Add tool results
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": "Search completed"
                })
        if tool_results:
            messages.append({"role": "user", "content": tool_results})

        final = client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=1500,
            tools=[{"type": "web_search_20250305", "name": "web_search"}],
            messages=messages
        )
        for block in final.content:
            if hasattr(block, 'text'):
                text_response += block.text

    return text_response

def parse_article(raw_text):
    """Extract JSON from Claude response."""
    # Try to find JSON in the response
    json_match = re.search(r'\{[\s\S]*\}', raw_text)
    if not json_match:
        raise ValueError("No JSON found in response")

    data = json.loads(json_match.group())

    # Validate required fields
    required = ["date", "title", "excerpt", "body"]
    for field in required:
        if field not in data:
            raise ValueError(f"Missing field: {field}")

    return data

def format_article_js(article, photo):
    """Format the article as a JavaScript object for the ARTICLES array."""
    # Escape any remaining problematic characters
    title   = article["title"].replace("'", "").replace('"', '')
    excerpt = article["excerpt"].replace("'", "").replace('"', '')
    body    = article["body"].replace("'", "").replace('"', '').replace('\\n\\n', '\\\\n\\\\n')

    return (
        '{{'
        'tag:\'Events\','
        'icon:\'📣\','
        f'photo:\'{photo}\','
        f'date:\'{article["date"]}\','
        'rt:\'4 min\','
        f'title:"{title}",'
        f'ex:"{excerpt}",'
        f'body:"{body}"'
        '}}'
    ).replace('{{', '{').replace('}}', '}')

def insert_article_into_html(html_content, article_js):
    """Insert the new article at the start of the ARTICLES array."""
    # Find the ARTICLES array
    marker = 'const ARTICLES=['
    idx = html_content.find(marker)
    if idx == -1:
        raise ValueError("Could not find ARTICLES array in HTML")

    insert_pos = idx + len(marker)

    # Insert the new article at the very beginning
    new_content = (
        html_content[:insert_pos]
        + '\n  ' + article_js + ',\n  '
        + html_content[insert_pos:].lstrip()
    )

    # Keep only the 12 most recent articles (trim the oldest)
    # Count existing articles
    arts_start = new_content.find('const ARTICLES=[')
    arts_end   = new_content.find('];', arts_start)
    arts_block = new_content[arts_start:arts_end + 2]
    count = arts_block.count('{tag:')

    if count > 12:
        print(f"Trimming articles from {count} to 12...")
        # Remove the last article entry
        last_comma = arts_block.rfind(',\n  {tag:')
        if last_comma > 0:
            last_entry_end = arts_end
            last_entry_start = arts_block.rfind('{tag:', 0, len(arts_block) - 5)
            trimmed_block = arts_block[:arts_start + last_entry_start - 4] + '];'
            new_content = new_content[:arts_start] + trimmed_block + new_content[arts_end + 2:]

    return new_content

def main():
    if not API_KEY:
        raise EnvironmentError("CLAUDE_API_KEY environment variable not set")

    print("Syneth Digital — Quarterly Blog Updater")
    print(f"Running at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("-" * 45)

    # Load the website
    print("Loading index.html...")
    with open(HTML_FILE, 'r', encoding='utf-8') as f:
        html = f.read()

    # Initialise Claude client
    client = anthropic.Anthropic(api_key=API_KEY)

    # Find event and write article
    print("Searching for recent Lagos marketing events...")
    raw = find_event_and_write_article(client)
    print(f"Claude response received ({len(raw)} chars)")

    # Parse the article
    print("Parsing article...")
    article = parse_article(raw)
    print(f"Event: {article['title']}")
    print(f"Date:  {article['date']}")

    # Format as JavaScript
    photo = get_photo()
    article_js = format_article_js(article, photo)
    print(f"Article formatted ({len(article_js)} chars)")

    # Insert into HTML
    print("Inserting article into index.html...")
    updated_html = insert_article_into_html(html, article_js)

    # Save
    with open(HTML_FILE, 'w', encoding='utf-8') as f:
        f.write(updated_html)

    print("-" * 45)
    print("Done. Article added successfully.")
    print(f"Title: {article['title']}")

if __name__ == "__main__":
    main()
